<?php $getCommonSetting = getCommonSetting();?>
<div class="navbar-brand">
    <button class="btn-menu ls-toggle-btn" type="button"><i class="zmdi zmdi-menu"></i></button>
    <a href=""><img src="<?php echo e(asset(''.$getCommonSetting->logo_header)); ?>" alt="<?php echo e($getCommonSetting->site_title); ?>"></a>
</div>
<div class="menu">
    <ul class="list">

        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i><span>Add Banner</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/all-banner')); ?>"><span>All Banner</span></a></li>
                <li><a href="<?php echo e(url('admin/add-banner')); ?>"><span>Add Banner</span></a></li>
            </ul>
        </li>


        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i><span>Category</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/categories?type=product')); ?>"><span> Categories</span></a></li>
                <li><a href="<?php echo e(url('admin/categories?type=brands')); ?>"><span> Brands</span></a></li>
            </ul>
        </li>










        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i>
                <span>Offers & Discount</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/offers')); ?>"><span>All Offers</span></a></li>
            </ul>
        </li>












        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i><span>Blog</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/add-posts?type=article')); ?>" class=" waves-effect waves-block"><span>Add Posts</span></a></li>
                <li><a href="<?php echo e(url('admin/all-post?type=all-posts')); ?>" class=" waves-effect waves-block"><span>Posts</span></a></li>

            </ul>
        </li>

































        
        <li><a href="<?php echo e(url('admin/common-settings')); ?>" class=" waves-effect waves-block"><i class="zmdi zmdi-book-image"></i><span>Common Settings</span></a></li>

    </ul>
</div>
<?php /**PATH H:\xampp\htdocs\perfumecom\resources\views/inc/admin/left-sidebar.blade.php ENDPATH**/ ?>