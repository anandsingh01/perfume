<?php

namespace App\Http\Controllers;

use App\Models\AboutModels;
use App\Models\AnnualReportModel;
use App\Models\BannerModel;
use App\Models\Blog;
use App\Models\Category;
use App\Models\CollaborationModel;
use App\Models\FounderModel;
use App\Models\MetalModel;
use App\Models\MissionModel;
use App\Models\Product;
use App\Models\ProjectDetail;
use App\Models\ProjectModel;
use App\Models\ServiceModel;
use App\Models\SupportModel;
use App\Models\Team;
use App\Models\Goals;
use App\Models\WhoWeAre;
use App\Models\Payment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Session;
use Razorpay\Api\Api;

use Auth;
class HomeController extends Controller
{
    public function index()
    {
        $data['get_hero_banner'] = BannerModel::where([
            'display_area'=> '1',
            'status'=> '1',
        ])->get();
        $data['category_on_home'] = Category::where([
            'status'=>'1',
            'show_on_homepage'=>'1',
            'category_type' => 'product'
            ])->get();
        $data['brand_on_home'] = Category::where([
            'status'=>'1',
            'show_on_homepage'=>'1',
            'category_type' => 'brands'
        ])->get();

        $data['get_product_favorites'] = Product::where([
            'status'=> 'active',
        ])
            ->with('get_brands','section')
            ->get();

        $data['get_recent_product'] = Product::where([
            'status'=> 'active',
            'highlights' => '1'
        ])
            ->orderBy('id','DESC')
            ->with('get_brands','section')
            ->get();

        $data['get_middle_banner'] = BannerModel::where([
            'display_area'=> '3',
            'status'=> '1',
        ])->orderBy('id','DESC')->first();

        $data['get_footer_banner'] = BannerModel::where([
            'display_area'=> '4',
            'status'=> '1',
        ])->orderBy('id','DESC')->first();
        return view('web.index',$data);
    }

    function product_by_category($slug){
        $category = Category::where('slug',$slug)->first();
        if(!empty($category)){
            $data['get_products'] = Product::where([
                'section_id' => $category->id,
                'status' => 'active',
                ]
            )
                ->with('get_brands','section')
                ->orderBy('id','DESC')
                ->get();
            $data['category'] = $category;
        }
        return view('web.category',$data);
    }

    function product_by_brands($slug){
        $brands = Category::where('slug',$slug)->first();
        if(!empty($brands)){
            $data['get_products'] = Product::where([
                'brands_id' => $brands->id,
                'status' => 'active',
                ]
            )
                ->with('get_brands','section')
                ->orderBy('id','DESC')
                ->get();
            $data['category'] = $brands;
        }
        return view('web.category',$data);
    }

    function contactus(){
        return view('web.contact');
    }



    function products_details($url){
        $data['get_middle_banner'] = BannerModel::where([
            'display_area'=> '3',
            'status'=> '1',
        ])->orderBy('id','DESC')->first();

        $data['product'] = Product::where('slug',$url)
            ->with(
                'getPrices',
                'getGallery',
                'get_brands',
                'section'
            )
            ->first();
        return view('web.product-details',$data);
    }

    public function searchTitle(Request $request)
    {
//        print_r($request->all());die;
        $query = $request->input('query');

//        print_r($query);die;

        // Query the products table for titles matching the query
        $products = Product::where('title', 'like', '%' . $query . '%')->get()->pluck('title', 'slug');

        return $products;
    }

    public function filter(Request $request) {
//        $selectedCategories = $request->input('categories', []);
//        $selectedBrands = $request->input('brands', []);
//
//        $filteredProducts = Product::whereIn('section_id', $selectedCategories)
//            ->whereIn('brands_id', $selectedBrands)
//            ->get();
//
//        if ($request->ajax()) {
//            return view('web.filtered_products', ['get_products' => $filteredProducts]);
//        }

        $selectedCategories = $request->input('categories', []);
        $selectedBrands = $request->input('brands', []);

        $query = Product::query();

        if (!empty($selectedCategories)) {
            $query->whereIn('section_id', $selectedCategories);
        }

        if (!empty($selectedBrands)) {
            $query->whereIn('brands_id', $selectedBrands);
        }

        $filteredProducts = $query->get();

        if ($request->ajax()) {
            return view('web.filtered_products', ['get_products' => $filteredProducts]);
        }

    }


    function blogs(){

    }

    function get_easyship(){

// Replace 'YOUR_API_KEY' with your actual Easyship API key
        $apiKey = 'sand_v7eM+nJIdcim+OXo4s3PvFG6A1idMJ9PbvUqp3/ltBE=';

// Set the API endpoint URL
        $url = 'https://api.easyship.com/rate/v1/rates';

// Set headers
        $headers = array(
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json'
        );

// Set request data
        $data = array(
            'origin_country_alpha2' => 'US',
            'destination_country_alpha2' => 'CA',
            'destination_postal_code' => 'M5V 2T6',
            'items' => array(
                array(
                    'actual_weight' => 1, // Weight in kg
                    'height' => 10, // Dimensions in cm
                    'width' => 10,
                    'length' => 10,
                    'category' => 'fashion'
                )
            )
        );

// Initialize cURL session
        $ch = curl_init();

// Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL request
        $response = curl_exec($ch);

// Close cURL session
        curl_close($ch);

// Decode JSON response
        $result = json_decode($response, true);

// Output shipping quotes
        print_r($result);


    }
}
